# -*- coding: utf-8; mode: python -*-
from mensaje import *

# Abrimos el puerto del arduino a 115200
PuertoSerie = abrirPort("COM1")  # cambiar al puerto apropiado


while True:
    print( "Esperando petición...")
    r = receiveMensaje(PuertoSerie)
    print(r)
    v = input("Escribe mensaje: ")
    mensa = v + "\n"
    sendMensaje(PuertoSerie, mensa )
